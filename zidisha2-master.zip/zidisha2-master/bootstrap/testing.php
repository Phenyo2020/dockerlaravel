<?php

//require 'autoload.php';
define('LARAVEL_ENV', 'testing');
return require 'start.php';
