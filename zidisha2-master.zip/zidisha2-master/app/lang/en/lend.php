<?php
return array(
    'page-title' => 'Lend',
    'page-header' => 'Lend',
    'loan' => array(
        'amount' => 'Loan Amount',
        'interest-rate' => 'Interest Rate',
    ),
    'category' => array(
        'how-it-works' => 'How it works',
        'why-important' => "Why it's important",
        'what-your-loan-do' => 'What your loan can do',
    ),
    'sidebar' => array(
        'category-heading' => 'Categories',
        'country-heading' => 'Countries',
    ),
);