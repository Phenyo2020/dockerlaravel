<?php
return [
  'loan-confirmation-subject' => 'Your Loan Application Has Been Published',

];