<?php

return [
    'form' => [
        'username' => 'Display Username',
        'email' => 'Email',
        'password' => 'Password',
        'password_confirmation' => 'Confirm Password',
        'submit' => 'Submit',
    ],
];
