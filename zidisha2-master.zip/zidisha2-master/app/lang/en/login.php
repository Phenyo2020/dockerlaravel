<?php

return [
    'facebook_login' => 'Login With Facebook',
    'form' => [
        'username' => 'Username or Email',
        'password' => 'Password',
        'remember_me' => 'Remember Me',
        'submit' => 'Login',
    ]
];
