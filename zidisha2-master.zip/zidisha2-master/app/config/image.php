<?php
return [
    'allowed-file-size' => '2097152',

    'formats' => [
        'small-profile-picture' => [
            'width' => '150',
            'height' => null
        ],
        'medium-profile-picture' => [
            'width' => '400',
            'height' => null
        ],
    ],
];
