<?php

namespace Zidisha\Country;

use Zidisha\Country\Base\Language as BaseLanguage;

class Language extends BaseLanguage
{

}
