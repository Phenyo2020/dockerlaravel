<?php

namespace Zidisha\Comment;

use Zidisha\Comment\Base\CommentsArchive as BaseCommentsArchive;

class CommentsArchive extends BaseCommentsArchive
{

}
