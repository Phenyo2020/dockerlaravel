<?php

namespace Zidisha\Comment;

use Zidisha\Comment\Base\CommentUploads as BaseCommentUploads;

class CommentUploads extends BaseCommentUploads
{

}
