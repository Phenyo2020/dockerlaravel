<?php

namespace Zidisha\Comment;

use Zidisha\Comment\Base\CommentUpload as BaseCommentUpload;

class CommentUpload extends BaseCommentUpload
{

}
