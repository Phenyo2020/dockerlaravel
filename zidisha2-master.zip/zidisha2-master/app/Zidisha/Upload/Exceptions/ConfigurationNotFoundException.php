<?php
namespace Zidisha\Upload\Exceptions;


class ConfigurationNotFoundException extends \Exception{

}
