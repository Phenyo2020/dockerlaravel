<?php
namespace Zidisha\Upload\Exceptions;


class FileTypeMisMatchException extends \Exception{

}
