<?php

namespace Zidisha\Repayment;

use Zidisha\Repayment\Base\InstallmentPayment as BaseInstallmentPayment;

class InstallmentPayment extends BaseInstallmentPayment
{

}
