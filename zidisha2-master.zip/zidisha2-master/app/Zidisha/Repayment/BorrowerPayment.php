<?php

namespace Zidisha\Repayment;

use Zidisha\Repayment\Base\BorrowerPayment as BaseBorrowerPayment;

class BorrowerPayment extends BaseBorrowerPayment
{

}
