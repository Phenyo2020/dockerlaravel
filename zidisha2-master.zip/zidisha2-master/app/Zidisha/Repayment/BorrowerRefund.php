<?php

namespace Zidisha\Repayment;

use Zidisha\Repayment\Base\BorrowerRefund as BaseBorrowerRefund;

class BorrowerRefund extends BaseBorrowerRefund
{

}
