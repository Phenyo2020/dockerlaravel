<?php

namespace Zidisha\Balance;

use Zidisha\Balance\Base\InviteTransactionQuery as BaseInviteTransactionQuery;


/**
 * Skeleton subclass for performing query and update operations on the 'lender_invite_transactions' table.
 *
 *
 *
 * You should add additional methods to this class to meet the
 * application requirements.  This class will only be generated as
 * long as it does not already exist in the output directory.
 *
 */
class InviteTransactionQuery extends BaseInviteTransactionQuery
{

} // InviteTransactionQuery
