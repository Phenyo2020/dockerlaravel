<?php

namespace Zidisha\Balance;

use Zidisha\Balance\Base\InviteTransaction as BaseInviteTransaction;

class InviteTransaction extends BaseInviteTransaction
{

}
