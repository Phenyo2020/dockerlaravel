<?php

namespace Zidisha\Translation;

use Zidisha\Translation\Base\TranslationLabelsArchive as BaseTranslationLabelsArchive;

class TranslationLabelsArchive extends BaseTranslationLabelsArchive
{

}
