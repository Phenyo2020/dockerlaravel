<?php

namespace Zidisha\Translation;

use Zidisha\Translation\Base\TranslationLabel as BaseTranslationLabel;

class TranslationLabel extends BaseTranslationLabel
{

}
