<?php

namespace Zidisha\Currency\Exception;

class InvalidCurrencyExchangeException extends \Exception
{

}
