<?php

namespace Zidisha\Notification;

use Zidisha\Notification\Base\Notification as BaseNotification;

class Notification extends BaseNotification
{

}
