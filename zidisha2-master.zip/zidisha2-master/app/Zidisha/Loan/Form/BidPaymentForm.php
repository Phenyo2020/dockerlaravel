<?php
namespace Zidisha\Loan\Form;

use Zidisha\Payment\Form\AbstractPaymentForm;

class BidPaymentForm extends AbstractPaymentForm
{
    public function getPayment()
    {

    }
}