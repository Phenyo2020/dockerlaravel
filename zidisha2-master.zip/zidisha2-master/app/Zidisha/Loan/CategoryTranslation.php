<?php

namespace Zidisha\Loan;

use Zidisha\Loan\Base\CategoryTranslation as BaseCategoryTranslation;

class CategoryTranslation extends BaseCategoryTranslation
{

}
