<?php

namespace Zidisha\Loan;

use Zidisha\Loan\Base\ForgivenLoan as BaseForgivenLoan;

class ForgivenLoan extends BaseForgivenLoan
{

}
