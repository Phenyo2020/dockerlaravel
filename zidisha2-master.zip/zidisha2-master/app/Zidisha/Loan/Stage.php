<?php

namespace Zidisha\Loan;

use Zidisha\Loan\Base\Stage as BaseStage;

class Stage extends BaseStage
{

}
