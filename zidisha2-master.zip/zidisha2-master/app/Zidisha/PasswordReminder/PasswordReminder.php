<?php

namespace Zidisha\PasswordReminder;

use Zidisha\PasswordReminder\Base\PasswordReminder as BasePasswordReminder;

class PasswordReminder extends BasePasswordReminder
{

}
