<?php
namespace Zidisha\Payment\Bid;


use Zidisha\Payment\PaymentHandler;

class BidPaymentCompletedHandler extends PaymentHandler
{
    public function process()
    {

    }

    public function redirect()
    {

    }
}