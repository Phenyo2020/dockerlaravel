<?php
namespace Zidisha\Payment\Bid;


use Zidisha\Payment\PaymentHandler;

class BidPaymentPendingHandler extends PaymentHandler{

    public function process()
    {
        // TODO: Implement process() method.
    }

    public function redirect()
    {
        // TODO: Implement redirect() method.
    }
}