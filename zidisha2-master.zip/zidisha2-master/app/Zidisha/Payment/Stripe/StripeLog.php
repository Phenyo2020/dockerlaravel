<?php

namespace Zidisha\Payment\Stripe;

use Zidisha\Payment\Stripe\Base\StripeLog as BaseStripeLog;

class StripeLog extends BaseStripeLog
{

}
