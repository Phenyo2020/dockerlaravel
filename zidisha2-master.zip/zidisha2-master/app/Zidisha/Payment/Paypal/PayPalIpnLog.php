<?php

namespace Zidisha\Payment\Paypal;

use Zidisha\Payment\Paypal\Base\PayPalIpnLog as BasePayPalIpnLog;

class PayPalIpnLog extends BasePayPalIpnLog
{

}
