<?php
namespace Zidisha\Payment\Paypal;


class PaypalTransactionFailedException  extends \Exception{

}
