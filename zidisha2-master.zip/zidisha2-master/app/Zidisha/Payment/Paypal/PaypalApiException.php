<?php
namespace Zidisha\Payment\Paypal;


class PaypalApiException extends \Exception{

} 