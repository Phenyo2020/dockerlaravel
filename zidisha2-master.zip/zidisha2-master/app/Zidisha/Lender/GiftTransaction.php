<?php

namespace Zidisha\Lender;

use Zidisha\Lender\Base\GiftTransaction as BaseGiftTransaction;

class GiftTransaction extends BaseGiftTransaction
{

}
