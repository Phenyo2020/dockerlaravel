<?php

namespace Zidisha\Lender;

use Zidisha\Lender\Base\LendingGroupMember as BaseLendingGroupMember;

class LendingGroupMember extends BaseLendingGroupMember
{

}
