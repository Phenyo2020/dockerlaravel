<?php

namespace Zidisha\Lender;

use Zidisha\Lender\Base\Invite as BaseInvite;

class Invite extends BaseInvite
{

}
