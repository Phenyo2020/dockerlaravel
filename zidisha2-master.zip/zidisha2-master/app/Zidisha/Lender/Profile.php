<?php

namespace Zidisha\Lender;

use Zidisha\Lender\Base\Profile as BaseProfile;

class Profile extends BaseProfile
{

}
