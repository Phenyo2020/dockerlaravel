<?php
namespace Zidisha\Lender\Exceptions;


class InsufficientLenderBalanceException extends \Exception{

}
