<?php

namespace Zidisha\Borrower;

use Zidisha\Borrower\Base\Profile as BaseProfile;

class Profile extends BaseProfile
{

}
