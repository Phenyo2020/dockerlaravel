<?php

namespace Zidisha\Borrower;

use Zidisha\Borrower\Base\VolunteerMentor as BaseVolunteerMentor;

class VolunteerMentor extends BaseVolunteerMentor
{

}
