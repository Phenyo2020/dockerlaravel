<?php

namespace Zidisha\Borrower;

use Zidisha\Borrower\Base\BorrowerGuest as BaseBorrowerGuest;

class BorrowerGuest extends BaseBorrowerGuest
{

}
