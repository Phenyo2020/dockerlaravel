<?php

namespace Zidisha\Borrower;

use Zidisha\Borrower\Base\BorrowerUpload as BaseBorrowerUpload;

class BorrowerUpload extends BaseBorrowerUpload
{

}
