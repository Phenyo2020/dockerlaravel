<?php

namespace Zidisha\Borrower;

use Zidisha\Borrower\Base\JoinLog as BaseJoinLog;

class JoinLog extends BaseJoinLog
{

}
