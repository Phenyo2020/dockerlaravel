<?php
namespace Zidisha\User\Exceptions;


class InvalidUserRoleException extends \Exception{

} 