Use this gift card to make a loan to a small business owner from around the world.
Communicate directly with him or her as the business you funded grows. Then relend your funds to another individual of your choice, spreading opportunity while getting to know some of the world's most remarkable entrepreneurs.
<br/><br/>
Amount: {{ $card->getCardAmount() }} <br/><br/>
Redemption Code: {{ $card->getCardCode() }}<br/><br/>
<i>Redeem this card by making a loan <a href="{{ route('lend:index') }}">here</a>. You may enter the redemption code in the Lending Cart after
    choosing an entrepreneur to support.</i>
