<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">
</head>
<body>
{{ $body }}

<hr/>
{{ var_dump($data) }}
</body>
</html>
