Dear {{ $borrower->getName() }},
<br/><br/>
Thank you for your application to join Zidisha.
<br/><br/>
A Zidisha staff member will
now review your account, a process that normally takes up to one week.  You will be notified by email when the review is
complete.  You may also log in to Zidisha to check the status of your account at any time.
<br/><br/>

Regards,
<br/><br/>
The Zidisha Team
