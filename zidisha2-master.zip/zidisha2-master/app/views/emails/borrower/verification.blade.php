<h1>Please click on the link to verify the email.</h1>
<br/>
<hr/>
<a href="{{ route('borrower:verify', $hashCode) }}">Verify</a>
