Dear {{ $borrowerName }},
<br/><br/>
We regret to inform you that your Zidisha account cannot be activated,
because we were unable to confirm that your account meets all required criteria for a Zidisha loan.
<br/><br/>
Best wishes,
<br/><br/>
Zidisha Team
