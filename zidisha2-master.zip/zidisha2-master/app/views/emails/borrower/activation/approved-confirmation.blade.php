Dear {{ $borrowerName }},
<br/><br/>
Congratulations! Your application to join Zidisha has been approved.
<br/><br/>
Zidisha is an internet-based community based on earned trust.
Membership is highly selective, and being accepted into Zidisha is something to take pride in.
<br/><br/>
You are now eligible to offer a loan agreement to Zidisha lenders.
To post a loan application on Zidisha, please log in to your member account at
<a href="%zidisha_link%TODO" target="_blank">Zidisha.org</a> and follow the instructions.
<br/><br/>
Best wishes,
<br/><br/>
The Zidisha Team
