@extends('layouts.master')

@section('content')

Your Loan has been submitted!!
@stop
