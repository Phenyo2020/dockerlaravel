@extends('layouts.master')

@section('page-title')
Volunteer Mentor Frequently asked questions
@stop

@section('content')

<h1>Volunteer Mentor Frequently asked questions</h1>

@stop