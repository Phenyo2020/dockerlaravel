@extends('layouts.master')

@section('page-title')
Volunteer Mentor Code of Ethics
@stop

@section('content')

<h1>Volunteer Mentor Code of Ethics</h1>

@stop