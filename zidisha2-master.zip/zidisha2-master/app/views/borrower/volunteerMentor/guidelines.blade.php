@extends('layouts.master')

@section('page-title')
Volunteer Mentor Guidelines
@stop

@section('content')

<h1>Volunteer Mentor Guidelines</h1>

<a href="{{ route('page:volunteer-mentor-code-of-ethics') }}" >Code of Ethics</a>
<br><br>
<a href="{{ route('page:volunteer-mentor-faq') }}" >Frequently asked questions</a>
@stop