@extends('layouts.master')

@section('page-title')
Transaction History
@stop

@section('content')
<div class="page-header">
    <h1>Transaction History</h1>
</div>

<h2>Transaction History for Borrower</h2>

@stop
