<div class="alert alert-{{ $level }}">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
    <h4>{{ $message }}</h4>
</div>
