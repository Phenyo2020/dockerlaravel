<div class="row">
    <div class="col-sm-7">
        <div class="progress">
            <div class="progress-bar" role="progressbar" aria-valuenow="{{$raised}}" aria-valuemin="0"
                 aria-valuemax="100"
                 style="width: {{$raised}}%;">
            </div>
        </div>
    </div>
    <div class="col-sm-5">
        <strong>{{ $raised }}% Raised</strong>
    </div>
</div>
