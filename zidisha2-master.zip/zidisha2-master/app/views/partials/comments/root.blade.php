<li>
    <ul>
        @include("partials.comments.comment", ['comment' => $comment])
    </ul>
</li>
